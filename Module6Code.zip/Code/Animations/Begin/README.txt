If you’d like to run a local server using Node.js do the following:

1. Install the latest Node.js LTS version on your machine from https://nodejs.org
2. Open a command window in this folder and run the following command:

node server.js

3. Open the browser and navigate to http://localhost:8080